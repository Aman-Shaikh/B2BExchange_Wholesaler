
const myDefaultSize = 30.0;
const mySplashContainerSize = 30.0;
const myButtonHeight = 15.0;
const myFormHeight = 30.0;